<template lang="pug">
  h1 Welcome to the Vue App
</template>