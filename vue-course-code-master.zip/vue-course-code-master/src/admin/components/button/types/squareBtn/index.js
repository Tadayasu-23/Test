export { default } from "./squareBtn.vue";
